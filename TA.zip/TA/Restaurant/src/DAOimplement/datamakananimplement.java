/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package DAOimplement;
import java.util.List;
import model.*;
/**
 *
 * @author ASUS
 */
public interface datamakananimplement {
    public void insert(datamakanan dmkn);
    public void update(datamakanan dmkn);
    public void delete(int idmkn);
    public List<datamakanan> getALL();
    
}
