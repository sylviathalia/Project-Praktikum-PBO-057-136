/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package DAOimplement;
import java.util.List;
import model.*;
/**
 *
 * @author ASUS
 */
public interface dataminumanimplement {
    public void insert(dataminuman dmnn);
    public void update(dataminuman dmnn);
    public void delete(int idmnn);
    public List<dataminuman> getALL();
}
