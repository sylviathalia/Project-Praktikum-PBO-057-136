/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package DAOimplement;
import java.util.List;
import model.*;
/**
 *
 * @author ASUS
 */
public interface transaksiimplement {
    public void insert(transaksi trns);
    public void update(transaksi trns);
    public void delete(int idtrans);
    public List<transaksi> getALL();
}
