/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author ASUS
 */
public class datakasir {
    private int id_kasir;
    private String nama_kasir;
    private String no_telp_kasir;
    private String alamat_kasir;

    public int getId_kasir() {
        return id_kasir;
    }

    public void setId_kasir(int id_kasir) {
        this.id_kasir = id_kasir;
    }

    public String getNama_kasir() {
        return nama_kasir;
    }

    public void setNama_kasir(String nama_kasir) {
        this.nama_kasir = nama_kasir;
    }

    public String getNo_telp_kasir() {
        return no_telp_kasir;
    }

    public void setNo_telp_kasir(String no_telp_kasir) {
        this.no_telp_kasir = no_telp_kasir;
    }

    public String getAlamat_kasir() {
        return alamat_kasir;
    }

    public void setAlamat_kasir(String alamat_kasir) {
        this.alamat_kasir = alamat_kasir;
    }
    
    
}
