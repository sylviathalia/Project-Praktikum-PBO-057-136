/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author ASUS
 */
public class dataminuman {
    private int id_minuman;
    private String nama_minuman;
    private int harga_minuman;

    public int getId_minuman() {
        return id_minuman;
    }

    public void setId_minuman(int id_minuman) {
        this.id_minuman = id_minuman;
    }

    public String getNama_minuman() {
        return nama_minuman;
    }

    public void setNama_minuman(String nama_minuman) {
        this.nama_minuman = nama_minuman;
    }

    public int getHarga_minuman() {
        return harga_minuman;
    }

    public void setHarga_minuman(int harga_minuman) {
        this.harga_minuman = harga_minuman;
    }
    
    
    
    
}
