/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;
import java.util.List;
import javax.swing.table.AbstractTableModel;
/**
 *
 * @author ASUS
 */
public class modeltabeldatakasir extends AbstractTableModel{
    
    List<datakasir> dkasir;
    public modeltabeldatakasir(List<datakasir>dkasir){
        this.dkasir = dkasir;
    }

    @Override
    public int getRowCount() {
        return dkasir.size();
    }

    @Override
    public int getColumnCount() {
        return 4;
    }

    @Override
    public String getColumnName(int column) {
        switch(column){
            case 0:
                return "id";
            case 1:
                return "nama";
            case 2:
                return "no telp";
            case 3:
                return "alamat";
            default:
                return null;
        }
    }
    
    @Override
    public Object getValueAt(int row, int column) {
        switch(column){
            case 0:
                return dkasir.get(row).getId_kasir();
            case 1:
                return dkasir.get(row).getNama_kasir();
            case 2:
                return dkasir.get(row).getNo_telp_kasir();
            case 3:
                return dkasir.get(row).getAlamat_kasir();
            default:
                return null;
        }
    }
    
    
}
