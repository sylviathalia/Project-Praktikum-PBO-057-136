/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;
import java.util.List;
import javax.swing.table.AbstractTableModel;
/**
 *
 * @author ASUS
 */
public class modeltabeldatamakanan extends AbstractTableModel{
    
    List<datamakanan> dmakan;
    public modeltabeldatamakanan(List<datamakanan>dmakan) {
        this.dmakan = dmakan;
    }
    
    @Override
    public int getRowCount() {
        return dmakan.size();
    }

    @Override
    public int getColumnCount() {
        return 3;
    }
    
    @Override
    public String getColumnName(int column){
        switch(column){
            case 0:
                return "id";
            case 1:
                return "nama";
            case 2:
                return "harga";
            default:
                return null;
        }
    }

    @Override
    public Object getValueAt(int row, int column) {
        switch(column){
            case 0:
                return dmakan.get(row).getId_makanan();
            case 1:
                return dmakan.get(row).getNama_makanan();
            case 2:
                return dmakan.get(row).getHarga_makanan();
            default:
                return null;
        }
    }
    
}
