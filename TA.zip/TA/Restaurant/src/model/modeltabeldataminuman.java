/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;
import java.util.List;
import javax.swing.table.AbstractTableModel;
/**
 *
 * @author ASUS
 */
public class modeltabeldataminuman extends AbstractTableModel{
    
    List<dataminuman> dminum;
    public modeltabeldataminuman(List<dataminuman>dminum) {
        this.dminum = dminum;    
    }

    @Override
    public int getRowCount() {
        return dminum.size();
    }

    @Override
    public int getColumnCount() {
        return 3;
    }
    
    @Override
    public String getColumnName(int column) {
        switch(column){
            case 0:
                return "id";
            case 1:
                return "nama";
            case 2:
                return "harga";
            default:
                return null;
        }
                
    }

    @Override
    public Object getValueAt(int row, int column) {
        switch(column){
            case 0:
                return dminum.get(row).getId_minuman();
            case 1:
                return dminum.get(row).getNama_minuman();
            case 2:
                return dminum.get(row).getHarga_minuman();
            default:
                return null;
        }
    }
    
    
}
