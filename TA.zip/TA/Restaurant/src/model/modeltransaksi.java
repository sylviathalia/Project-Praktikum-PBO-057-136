/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;
import java.util.List;
import javax.swing.table.AbstractTableModel;
/**
 *
 * @author ASUS
 */
public class modeltransaksi extends AbstractTableModel{
    List<transaksi> trans;
    public modeltransaksi(List<transaksi>trans) {
        this.trans = trans; 
    }

    @Override
    public int getRowCount() {
        return trans.size();
    }

    @Override
    public int getColumnCount() {
        return 10;
    }

    @Override
    public String getColumnName(int column){
        switch(column){
            case 0:
                return "id";
            case 1:
                return "nama pelanggan";
            case 2:
                return "tanggal pemesanan";
            case 3:
                return "nama makanan";
            case 4:
                return "harga makanan";
            case 5:
                return "jumlah makanan";
            case 6:
                return "nama minuman";
            case 7:
                return "harga minuman";
            case 8:
                return "jumlah minuman";
            case 9:
                return "total harga";
            default:
                return null;
        }
    }
    
    @Override
    public Object getValueAt(int row, int column) {
        switch(column){
            case 0:
                return trans.get(row).getId_transaksi();
            case 1:
                return trans.get(row).getAtas_nama();
            case 2:
                return trans.get(row).getTanggal();
            case 3:
                return trans.get(row).getNama_makanan();
            case 4:
                return trans.get(row).getHarga_makanan();
            case 5:
                return trans.get(row).getJml_mkn();
            case 6:
                return trans.get(row).getHarga_minuman();
            case 7:
                return trans.get(row).getHarga_minuman();
            case 8:
                return trans.get(row).getJml_mnm();
            case 9:
                return trans.get(row).getTotal_harga();
            default:
                return null;
        }
    }
}
