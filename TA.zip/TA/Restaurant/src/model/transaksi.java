/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author ASUS
 */
public class transaksi {
    private int id_transaksi;
    private String atas_nama;
    private String tanggal;
    private int id_makanan;
    private String nama_makanan;
    private int harga_makanan;
    private int jml_mkn;
    private int id_minuman;
    private String nama_minuman;
    private int harga_minuman;
    private int jml_mnm;
    private int total_harga;

    public int getId_transaksi() {
        return id_transaksi;
    }

    public void setId_transaksi(int id_transaksi) {
        this.id_transaksi = id_transaksi;
    }

    public String getAtas_nama() {
        return atas_nama;
    }

    public void setAtas_nama(String atas_nama) {
        this.atas_nama = atas_nama;
    }

    public String getTanggal() {
        return tanggal;
    }

    public void setTanggal(String tanggal) {
        this.tanggal = tanggal;
    }

    public int getId_makanan() {
        return id_makanan;
    }

    public void setId_makanan(int id_makanan) {
        this.id_makanan = id_makanan;
    }

    public String getNama_makanan() {
        return nama_makanan;
    }

    public void setNama_makanan(String nama_makanan) {
        this.nama_makanan = nama_makanan;
    }

    public int getHarga_makanan() {
        return harga_makanan;
    }

    public void setHarga_makanan(int harga_makanan) {
        this.harga_makanan = harga_makanan;
    }

    public int getJml_mkn() {
        return jml_mkn;
    }

    public void setJml_mkn(int jml_mkn) {
        this.jml_mkn = jml_mkn;
    }

    public int getId_minuman() {
        return id_minuman;
    }

    public void setId_minuman(int id_minuman) {
        this.id_minuman = id_minuman;
    }

    public String getNama_minuman() {
        return nama_minuman;
    }

    public void setNama_minuman(String nama_minuman) {
        this.nama_minuman = nama_minuman;
    }

    public int getHarga_minuman() {
        return harga_minuman;
    }

    public void setHarga_minuman(int harga_minuman) {
        this.harga_minuman = harga_minuman;
    }

    public int getJml_mnm() {
        return jml_mnm;
    }

    public void setJml_mnm(int jml_mnm) {
        this.jml_mnm = jml_mnm;
    }

    public int getTotal_harga() {
        return total_harga;
    }

    public void setTotal_harga(int total_harga) {
        this.total_harga = total_harga;
    }
}
